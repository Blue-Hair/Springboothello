package com.spring.config;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * 全局异常捕捉类
 * 如果返回的是View---方法的返回值是ModelAndView
 * 如果返回的是String或者Json数据，那么需要在方法上添加@ResponseBody注解
 */
@ControllerAdvice
public class GlobalDefaultExceptionHandler {

    @ExceptionHandler(Exception.class)
    @ResponseBody
    public  String defaultExceptionHandler(HttpServletRequest request,Exception e){
        //ModelAndView 介绍模板引擎
//        ModelAndView modelAndView=new ModelAndView();
//        modelAndView.setViewName(iewName);
        return  "对不起，服务器繁忙,请稍后再试";
    }

}
