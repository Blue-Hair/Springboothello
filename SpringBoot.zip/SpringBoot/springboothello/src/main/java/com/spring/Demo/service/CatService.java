package com.spring.Demo.service;

import com.spring.Demo.bean.Cat;
import com.spring.Demo.repository.CatRepository;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.transaction.Transactional;

@Service
public class CatService {
    @Resource
    private CatRepository catRepository;

    /**
     * 需要绑定事务，使用   @Transactional
     * @param cat
     */
    //保存数据
    @Transactional
    public void save(Cat cat){
        catRepository.save(cat);
    }
    //删除数据
    @Transactional
    public  void delete(int  id){
        catRepository.delete(id);

    }
    //查询全部数据
    public  Iterable<Cat> getAll(){
        return  catRepository.findAll();
    }
    //根据条件查询数据(1自带)
    public Iterable<Cat> findByCatName(String catName){
        return  catRepository.findByCatName(catName);
    }
    //根据条件查询数据(2JPQL语法)
    public Iterable<Cat> findMyCatName(String catName){
        return  catRepository.findMyCatName(catName);
    }

    //根据id查询数据(JPQL语法)
    public Cat findCat(int id){
        return  catRepository.findCat(id);
    }

}
