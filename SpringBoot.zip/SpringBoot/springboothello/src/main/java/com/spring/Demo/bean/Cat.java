package com.spring.Demo.bean;

import javax.persistence.*;

/**
 *使用@Entity进行实体类的持久化操作，会在数据库生成对应表结构信息
 */
@Entity
//@Table(name = "cat")
public class Cat {

    /**
     * 使用@Id指定主键
     * 使用@GeneratedValu指定主键生成策略，默认自增长
     */
    @Id @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;//主键
    private String catName;//姓名 cat_name
    //@Column(name = "age")
    private int catAge;//年龄



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public int getCatAge() {
        return catAge;
    }

    public void setCatAge(int catAge) {
        this.catAge = catAge;
    }
}
