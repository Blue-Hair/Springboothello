package com.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Map;

/**
 *@RestController等价于@Controller和@ResponseBody
 */
@RestController
public class HelloController {

    /**
     * 使用@RequestMapping建立请求映射
     * @return
     */
    @RequestMapping("/test")
    public  String hello(){
        return  "HelloWord";
    }

    @RequestMapping("/test2")
    public  String hello2(){
        return "hello31";
    }

    /**
     * spring boot 默认使用的json解析框架是jackson
     * @return
     */
    @RequestMapping("getdemo")
    public  demo getDemo(){
        demo demo=new demo();
        demo.setId(1);
        demo.setName("洪文");
        demo.setCreateTime(new Date());
        demo.setRemarks("备注信息");
        return  demo;
    }
}
