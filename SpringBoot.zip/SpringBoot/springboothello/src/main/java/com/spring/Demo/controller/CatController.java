package com.spring.Demo.controller;

import com.spring.Demo.bean.Cat;
import com.spring.Demo.service.CatService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/cat")
public class CatController {

    @Resource
    private CatService catService;

    /**
     * 新增和更新
     * @return
     */
    @RequestMapping("/save")
    public  Map<String, Object>  save(){
        Cat cat=new Cat();
        cat.setCatName("snake");
        cat.setCatAge(1);
        //cat.setId(2);//更新
        catService.save(cat);
        Map<String, Object> result = new HashMap();
        result.put("code",200);
        result.put("message", "成功");
        result.put("data",cat);
        return  result;
    }

    /**
     * 删除
     * @return
     */
    @RequestMapping("/delete")
    public  String delete(){
        catService.delete(1);
        return  "delete ok";
    }

    /**
     * 查询
     * @return
     */
    @RequestMapping("/getAll")
    public  Iterable<Cat> getall(){
        return     catService.getAll();
    }

    @RequestMapping("/findByCatName")
    public Iterable<Cat> findByCatName(String catName){
        return     catService.findByCatName(catName);
    }

    @RequestMapping("/findMyCatName")
    public Map<String, Object>  findMyCatName(String catName){
        Map<String, Object> result = new HashMap();
        result.put("code",200);
        result.put("message", "成功");
        result.put("data",catService.findMyCatName(catName));
        return   result;
    }


    @RequestMapping("/findCat")
    public Cat findCat(int id){
        return     catService.findCat(id);
    }
}

