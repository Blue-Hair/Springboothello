package com.spring;

import com.alibaba.fastjson.annotation.JSONField;

import java.util.Date;

/**
 * 测试实体类
 */
public class demo {
    private int id;
    private String name;

    //测试fasonjson是否部署成功
    @JSONField(format = "yyyy-MM-dd HH:mm")
    private Date createTime;

    public Date getCreateTime() {
        return createTime;
    }

    /**
     * 不想返回这个属性可通过不序列化
     */
    @JSONField(serialize = false)
    private String remarks;

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
