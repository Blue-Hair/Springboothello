package com.spring.Demo.repository;

import com.spring.Demo.bean.Cat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CatRepository extends JpaRepository<Cat,Integer> {

    /**
     * 查询方法以get  find  read 开头
     * 条件的属性用条件关键字连接，条件属性首字母大写
     */
    //根据catName进行查询(返回一个数组)
    public Iterable<Cat> findByCatName(String catName);

    /**
     * 编写JPQL语句
     */
    @Query("select c from Cat c where c.catName=:cn")
    public  Iterable<Cat> findMyCatName(@Param("cn")String catName);

    /**
     * 编写JPQL语句
     */
    @Query("select d from Cat d where d.id=:id")
    public  Cat findCat(@Param("id")int id);

}
